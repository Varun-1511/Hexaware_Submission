package com.hexaware.hibernate.app;


import com.hexaware.hibernate.service.ProductService;
import com.hexaware.hibernate.entity.Product;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.util.Scanner;

public class App {

    public static void main(String[] args) {
        SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Product.class).buildSessionFactory();
        Session session = factory.openSession();
        ProductService productService = new ProductService(session);

        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("1. Add new Item");
            System.out.println("2. Remove Item (by item code)");
            System.out.println("3. Update Price of Item (by item code)");
            System.out.println("4. Calculate Total Bill (by item code and quantity)");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter product code: ");
                    int pid = scanner.nextInt();
                    System.out.print("Enter product name: ");
                    String name = scanner.next();
                    System.out.print("Enter product price: ");
                    double price = scanner.nextDouble();
                    productService.addProduct(pid, name, price);
                    break;
                case 2:
                    System.out.print("Enter product code to remove: ");
                    int removePid = scanner.nextInt();
                    productService.removeProduct(removePid);
                    break;
                case 3:
                    System.out.print("Enter product code to update: ");
                    int updatePid = scanner.nextInt();
                    System.out.print("Enter new price: ");
                    double newPrice = scanner.nextDouble();
                    productService.updatePrice(updatePid, newPrice);
                    break;
                case 4:
                    System.out.print("Enter product code to calculate bill: ");
                    int billPid = scanner.nextInt();
                    System.out.print("Enter quantity: ");
                    int quantity = scanner.nextInt();
                    productService.calculateTotalBill(billPid, quantity);
                    break;
                case 5:
                    System.out.println("Exiting");
                    break;
                default:
                    System.out.println("Invalid choice, try again.");
            }
        } while (choice != 5);

        session.close();
        factory.close();
        scanner.close();
    }
}
