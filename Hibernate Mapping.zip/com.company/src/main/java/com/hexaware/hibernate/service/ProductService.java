package com.hexaware.hibernate.service;

import com.hexaware.hibernate.dao.ProductDAO;
import com.hexaware.hibernate.entity.Product;
import org.hibernate.Session;
public class ProductService {
    private ProductDAO productDAO;

    public ProductService(Session session) {
        this.productDAO = new ProductDAO(session);
    }

    public void addProduct(int pid, String name, double price) {
        Product product = new Product();
        product.setPid(pid);
        product.setName(name);
        product.setPrice(price);
        productDAO.saveProduct(product);
    }

    public void removeProduct(int pid) {
        productDAO.deleteProduct(pid);
    }

    public void updatePrice(int pid, double newPrice) {
        productDAO.updateProductPrice(pid, newPrice);
    }

    public void calculateTotalBill(int pid, int quantity) {
        Product product = productDAO.getProductById(pid);
        if (product != null) {
            double total = product.getPrice() * quantity;
            System.out.println("Total Bill: " + total);
        } else {
            System.out.println("Product not found.");
        }
    }
}
