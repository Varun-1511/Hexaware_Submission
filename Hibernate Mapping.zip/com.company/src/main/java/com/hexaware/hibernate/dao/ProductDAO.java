package com.hexaware.hibernate.dao;


import com.hexaware.hibernate.entity.Product;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.List;

public class ProductDAO {
    private Session session;

    public ProductDAO(Session session) {
        this.session = session;
    }

    public void saveProduct(Product product) {
        Transaction tx = session.beginTransaction();
        session.save(product);
        tx.commit();
    }

    public void deleteProduct(int pid) {
        Transaction tx = session.beginTransaction();
        Query query = session.createQuery("delete from Product where pid = :pid");
        query.setParameter("pid", pid);
        int result = query.executeUpdate();
        tx.commit();
        if (result > 0) {
            System.out.println("Product removed successfully.");
        } else {
            System.out.println("Product not found.");
        }
    }

    public void updateProductPrice(int pid, double newPrice) {
        Transaction tx = session.beginTransaction();
        Query query = session.createQuery("update Product set price = :price where pid = :pid");
        query.setParameter("price", newPrice);
        query.setParameter("pid", pid);
        int result = query.executeUpdate();
        tx.commit();
        if (result > 0) {
            System.out.println("Price updated successfully.");
        } else {
            System.out.println("Product not found.");
        }
    }

    public Product getProductById(int pid) {
        return session.find(Product.class, pid);
    }
}
