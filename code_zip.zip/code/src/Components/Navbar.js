import React from 'react';
import { AppBar, Toolbar, Typography, Button, IconButton } from '@mui/material';
import { Link } from 'react-router-dom';
import MenuBookIcon from '@mui/icons-material/MenuBook';

const Navbar = () => {
    return (
        <AppBar position="static" sx={{ flexGrow: 1 }}>
            <Toolbar>
                <IconButton
                    edge="start"
                    color="inherit"
                    aria-label="menu"
                    sx={{ marginRight: 2 }}
                >
                    <MenuBookIcon />
                </IconButton>
                <Typography variant="h6" sx={{ flexGrow: 1 }}>
                    Book Haven
                </Typography>
                <Button
                    color="inherit"
                    component={Link}
                    to="/register"
                    sx={{
                        '&:hover': {
                            backgroundColor: '#ff4081',
                        },
                    }}
                >
                    Register
                </Button>
                <Button
                    color="inherit"
                    component={Link}
                    to="/admin-register"
                    sx={{
                        '&:hover': {
                            backgroundColor: '#ff4081',
                        },
                    }}
                >
                    Admin Access
                </Button>
            </Toolbar>
        </AppBar>
    );
};

export default Navbar;
