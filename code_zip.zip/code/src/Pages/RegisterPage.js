import React, { useState } from 'react';
import { TextField, Button, Typography, Container, Box, Alert } from '@mui/material';
import { Link, useNavigate } from 'react-router-dom';
import PersonAddAltIcon from '@mui/icons-material/PersonAddAlt';  // Import icon
import { styled } from '@mui/system';

const Register = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleRegister = async () => {
    const payload = {
      name: name,
      email: email,
      password: password,
      userRole: 'USER',
    };

    try {
      const response = await fetch('http://localhost:8080/api/auth/signup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        setError('User already exists or error in registration');
      } else {
        navigate('/login');
      }
    } catch (err) {
      setError('Failed to register. Try again later.');
    }
  };

  return (
    <Container maxWidth="sm">
      <StyledBox>
        <IconWrapper>
          <PersonAddAltIcon sx={{ fontSize: 50, color: '#fff' }} />
        </IconWrapper>
        <Typography variant="h4" sx={{ fontWeight: 'bold', mb: 2 }}>
          Create Account
        </Typography>
        {error && <Alert severity="error">{error}</Alert>}
        <TextField
          label="Name"
          variant="outlined"
          fullWidth
          margin="normal"
          value={name}
          onChange={(e) => setName(e.target.value)}
          sx={{ backgroundColor: '#f9f9f9' }}
        />
        <TextField
          label="Email"
          variant="outlined"
          fullWidth
          margin="normal"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          sx={{ backgroundColor: '#f9f9f9' }}
        />
        <TextField
          label="Password"
          variant="outlined"
          fullWidth
          type="password"
          margin="normal"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          sx={{ backgroundColor: '#f9f9f9' }}
        />
        <Button
          variant="contained"
          color="primary"
          fullWidth
          onClick={handleRegister}
          sx={{ mt: 2, py: 1, fontSize: '16px', backgroundColor: '#1976D2' }}
        >
          Register
        </Button>

        <Box mt={3}>
          <Typography variant="body2" sx={{ textAlign: 'center' }}>
            Already have an account?{' '}
            <Link to="/login" style={{ textDecoration: 'none', color: '#1976d2', fontWeight: 'bold' }}>
              Login
            </Link>
          </Typography>
        </Box>
      </StyledBox>
    </Container>
  );
};

// Custom styles
const StyledBox = styled(Box)(({ theme }) => ({
  marginTop: theme.spacing(8),
  padding: theme.spacing(5),
  borderRadius: '12px',
  backgroundColor: '#fff',
  boxShadow: '0px 4px 20px rgba(0, 0, 0, 0.1)',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
}));

const IconWrapper = styled(Box)(({ theme }) => ({
 backgroundColor: '#1976D2',
  borderRadius: '50%',
  width: '80px',
  height: '80px',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  marginBottom: theme.spacing(2),
}));

export default Register;
