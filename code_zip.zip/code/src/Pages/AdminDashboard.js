import React, { useState } from 'react';
import {
  Button,
  Container,
  Box,
  Typography,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  AppBar,
  Toolbar,
  IconButton,
  useTheme,
} from '@mui/material';
import { Book, Visibility } from '@mui/icons-material'; // Import Material UI icons
import ManageBooks from './ManageBooks';
import ViewData from './ViewData';

const AdminDashboard = () => {
  const [openManageBooks, setOpenManageBooks] = useState(false);
  const [openViewData, setOpenViewData] = useState(false);
  const theme = useTheme(); // Access the theme for colors

  const handleManageBooksOpen = () => setOpenManageBooks(true);
  const handleManageBooksClose = () => setOpenManageBooks(false);

  const handleViewDataOpen = () => setOpenViewData(true);
  const handleViewDataClose = () => setOpenViewData(false);

  return (
    <Container>
      <AppBar position="static" color="primary">
        <Toolbar>
          <Typography variant="h6">Book Management Admin</Typography>
        </Toolbar>
      </AppBar>
      <Box mt={4} mb={4} textAlign="center" sx={{ backgroundColor: theme.palette.grey[100], borderRadius: '8px', padding: '20px' }}>
        <Typography variant="h4" gutterBottom color="primary.main">
          Admin Dashboard
        </Typography>
        <Button
          variant="contained"
          color="success"
          onClick={handleManageBooksOpen}
          startIcon={<Book />} // Add an icon for Manage Books
        >
          Manage Books
        </Button>
        <Button
          variant="contained"
          color="info"
          onClick={handleViewDataOpen}
          startIcon={<Visibility />} // Add an icon for View Data
          sx={{ marginLeft: '16px' }}
        >
          View Data
        </Button>
      </Box>

      {/* Manage Books Modal */}
      <Dialog open={openManageBooks} onClose={handleManageBooksClose} fullWidth maxWidth="md">
        <DialogTitle>Manage Books</DialogTitle>
        <DialogContent>
          <ManageBooks />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleManageBooksClose} color="primary">
            Close
          </Button>
        </DialogActions>
      </Dialog>

      {/* View Data Modal */}
      <Dialog open={openViewData} onClose={handleViewDataClose} fullWidth maxWidth="md">
        <DialogTitle>View Data</DialogTitle>
        <DialogContent>
          <ViewData />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleViewDataClose} color="primary">
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default AdminDashboard;  
