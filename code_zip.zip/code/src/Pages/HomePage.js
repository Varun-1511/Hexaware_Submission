import React from 'react';
import Navbar from '../Components/Navbar'; // Assuming Navbar is in the Components folder
import { Box, Typography, Card, CardContent, CardMedia, Grid, Button } from '@mui/material';
import { Carousel } from 'react-responsive-carousel';
import 'react-responsive-carousel/lib/styles/carousel.min.css'; // carousel styles
import { Link } from 'react-router-dom';

const books = [
  {
    title: 'To Kill a Mockingbird',
    author: 'Harper Lee',
    img: 'https://cdn.britannica.com/21/182021-050-666DB6B1/book-cover-To-Kill-a-Mockingbird-many-1961.jpg',
  },
  {
    title: '1984',
    author: 'George Orwell',
    img: 'https://m.media-amazon.com/images/I/7180qjGSgDL._AC_UF1000,1000_QL80_.jpg',
  },
  {
    title: 'The Great Gatsby',
    author: 'F. Scott Fitzgerald',
    img: 'https://m.media-amazon.com/images/I/81YeMECEzXL._AC_UF1000,1000_QL80_.jpg',
  },
];

const HomePage = () => {
  return (
    <div>
      {/* Navbar */}
      <Navbar />

      {/* Slider Section */}
      <Box sx={{ maxWidth: '800px', margin: '40px auto' }}>
        <Carousel
          autoPlay
          infiniteLoop
          showThumbs={false}
          showStatus={false}
          interval={3000}
          emulateTouch
        >
          <div style={{ position: 'relative' }}>
            <img
              src="https://cdn.pixabay.com/photo/2016/08/24/16/20/books-1617327_1280.jpg"
              alt="Novel 1"
              style={{ height: '400px', objectFit: 'cover', filter: 'brightness(50%)' }}
            />
            <Typography
              variant="h5"
              align="center"
              sx={{
                position: 'absolute',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                color: '#fff',
                fontStyle: 'italic',
                maxWidth: '90%',
                textShadow: '2px 2px 8px rgba(0,0,0,0.7)',
              }}
            >
              "A room without books is like a body without a soul." – Marcus Tullius Cicero
            </Typography>
          </div>
          <div style={{ position: 'relative' }}>
            <img
              src="https://i.guim.co.uk/img/media/77e3e93d6571da3a5d77f74be57e618d5d930430/0_0_2560_1536/master/2560.jpg?width=1300&dpr=2&s=none"
              alt="Novel 2"
              style={{ height: '400px', objectFit: 'cover', filter: 'brightness(50%)' }}
            />
            <Typography
              variant="h5"
              align="center"
              sx={{
                position: 'absolute',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                color: '#fff',
                fontStyle: 'italic',
                maxWidth: '90%',
                textShadow: '2px 2px 8px rgba(0,0,0,0.7)',
              }}
            >
              "Books are a uniquely portable magic." – Stephen King
            </Typography>
          </div>
          <div style={{ position: 'relative' }}>
            <img
              src="https://cdn.pixabay.com/photo/2017/08/08/21/03/book-2612702_1280.jpg"
              alt="Novel 3"
              style={{ height: '400px', objectFit: 'cover', filter: 'brightness(50%)' }}
            />
            <Typography
              variant="h5"
              align="center"
              sx={{
                position: 'absolute',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                color: '#fff',
                fontStyle: 'italic',
                maxWidth: '90%',
                textShadow: '2px 2px 8px rgba(0,0,0,0.7)',
              }}
            >
              "A reader lives a thousand lives before he dies." – George R.R. Martin
            </Typography>
          </div>
        </Carousel>
      </Box>

      {/* Sample Book Cards Section */}
      <Box sx={{ maxWidth: '1200px', margin: '40px auto', padding: '0 16px' }}>
        <Typography variant="h4" align="center" gutterBottom>
          Sample Books
        </Typography>
        <Grid container spacing={4}>
          {books.map((book, index) => (
            <Grid item xs={12} sm={6} md={4} key={index}>
              <Card sx={{ maxHeight: '100%' }}>
                <CardMedia
                  component="img"
                  height="300"
                  image={book.img}
                  alt={book.title}
                  sx={{ objectFit: 'cover' }}
                />
                <CardContent>
                  <Typography variant="h6">{book.title}</Typography>
                  <Typography variant="subtitle1" color="textSecondary">
                    {book.author}
                  </Typography>
                  <Button
                    variant="contained"
                    color="primary"
                    component={Link}
                    to="/browse-products"
                    sx={{ marginTop: '10px' }}
                  >
                    View More
                  </Button>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Box>

      {/* Footer Section */}
      <Box
        sx={{
          backgroundColor: '#3f51b5',
          color: '#fff',
          padding: '20px',
          textAlign: 'center',
          marginTop: '40px',
        }}
      >
        <Typography variant="h6">Book Haven</Typography>
        <Typography variant="body2">
          &copy; {new Date().getFullYear()} Book Haven. All rights reserved.
        </Typography>
      </Box>
    </div>
  );
};

export default HomePage;
