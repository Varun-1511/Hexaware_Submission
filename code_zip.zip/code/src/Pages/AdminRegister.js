import React, { useState } from 'react';
import { TextField, Button, Typography, Container, Box, Alert, InputAdornment, IconButton } from '@mui/material';
import { Link, useNavigate } from 'react-router-dom';
import { Person as PersonIcon, Email as EmailIcon, Lock as LockIcon } from '@mui/icons-material';

const AdminRegister = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleAdminRegister = async () => {
    const payload = {
      name: name,
      email: email,
      password: password,
      userRole: 'ADMIN',  // Admin role
    };

    try {
      const response = await fetch('http://localhost:8080/api/auth/signup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        setError('Admin already exists or error in registration');
      } else {
        navigate('/admin-login');  // Redirect to admin login after successful signup
      }
    } catch (err) {
      setError('Failed to register admin. Try again later.');
    }
  };

  return (
    <Container maxWidth="xs" style={{ backgroundColor: '#f9f9f9', padding: '20px', borderRadius: '10px', boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.1)' }}>
      <Box textAlign="center" mb={3}>
        {/* <img src="/assets/admin-register-icon.png" alt="Admin Register" style={{ width: '100px', marginBottom: '20px' }} /> */}
        <Typography variant="h4" gutterBottom color="primary">
          Admin Register
        </Typography>
      </Box>
      {error && <Alert severity="error">{error}</Alert>}
      <TextField
        label="Name"
        variant="outlined"
        fullWidth
        margin="normal"
        value={name}
        onChange={(e) => setName(e.target.value)}
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <PersonIcon color="primary" />
            </InputAdornment>
          ),
        }}
      />
      <TextField
        label="Email"
        variant="outlined"
        fullWidth
        margin="normal"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <EmailIcon color="primary" />
            </InputAdornment>
          ),
        }}
      />
      <TextField
        label="Password"
        variant="outlined"
        fullWidth
        type="password"
        margin="normal"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <LockIcon color="primary" />
            </InputAdornment>
          ),
        }}
      />
      <Button
        variant="contained"
        color="primary"
        fullWidth
        style={{ marginTop: '20px', padding: '10px' }}
        onClick={handleAdminRegister}
      >
        Register
      </Button>

      <Box mt={2} textAlign="center">
        <Typography variant="body2" color="textSecondary">
          Already have an admin account?{' '}
          <Link to="/admin-login" style={{ textDecoration: 'none', color: '#1976d2' }}>
            Login
          </Link>
        </Typography>
      </Box>
    </Container>
  );
};

export default AdminRegister;
