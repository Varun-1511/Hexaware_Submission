import React, { useEffect, useState } from 'react';
import { AppBar, Toolbar, Button, Container, Grid, Card, CardContent, CardMedia, Typography, Box } from '@mui/material';
import { useNavigate } from 'react-router-dom';

const BrowseProducts = () => {
    const [books, setBooks] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        fetchBooks();
    }, []);

    const fetchBooks = async () => {
        try {
            const response = await fetch('http://localhost:8080/api/admin/getAllBooks');
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const data = await response.json();
            console.log('Fetched books:', data);
            setBooks(data);
        } catch (error) {
            console.error('Error fetching books:', error);
        }
    };

    const handleLogout = () => {
        localStorage.removeItem('token'); // Remove token from local storage
        navigate('/login'); // Redirect to login page
    };

    return (
        <>
            {/* Navbar */}
            <AppBar position="static" sx={{ backgroundColor: '#1976D2', mb: 4 }}>
                <Toolbar sx={{ display: 'flex', justifyContent: 'space-between' }}>
                    <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
                        Book Dashboard
                    </Typography>
                    <Button color="inherit" onClick={handleLogout} sx={{ fontWeight: 'bold' }}>
                        Logout
                    </Button>
                </Toolbar>
            </AppBar>

            {/* Book Dashboard */}
            <Container>
                <Box mt={4} mb={4}>
                    <Typography variant="h4" align="center" gutterBottom sx={{ color: '#4CAF50' }}>
                        Available Books
                    </Typography>
                </Box>
                <Grid container spacing={4} justifyContent="center">
                    {books.length > 0 ? (
                        books.map((book) => (
                            <Grid item key={book.isbn} xs={12} sm={6} md={4}>
                                <Card
                                    sx={{
                                        height: '100%',
                                        display: 'flex',
                                        flexDirection: 'column',
                                        justifyContent: 'space-between',
                                        backgroundColor: '#f5f5f5',
                                        boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.15)',
                                        borderRadius: '12px',
                                        transition: 'transform 0.3s ease-in-out',
                                        '&:hover': {
                                            transform: 'scale(1.06)',
                                            boxShadow: '0px 6px 15px rgba(0, 0, 0, 0.25)',
                                        },
                                    }}
                                >
                                    <CardMedia
                                        component="img"
                                        height="200"
                                        image={book.imageUrl || 'https://via.placeholder.com/200'}
                                        alt={book.title}
                                        sx={{ objectFit: 'cover', borderRadius: '12px 12px 0 0' }}
                                    />
                                    <CardContent
                                        sx={{
                                            backgroundColor: '#ffffff',
                                            textAlign: 'center',
                                            padding: '16px',
                                        }}
                                    >
                                        <Typography
                                            gutterBottom
                                            variant="h5"
                                            component="div"
                                            sx={{ color: '#1976D2', fontWeight: 'bold' }}
                                        >
                                            {book.title}
                                        </Typography>
                                        <Typography
                                            variant="body2"
                                            sx={{ color: '#9E9E9E', fontSize: '1rem', marginBottom: '8px' }}
                                        >
                                            Author: {book.author || 'Unknown'}
                                        </Typography>
                                        <Typography variant="body2" sx={{ color: '#616161', fontSize: '1rem' }}>
                                            Year: {book.publicationYear || 'N/A'}
                                        </Typography>
                                    </CardContent>
                                </Card>
                            </Grid>
                        ))
                    ) : (
                        <Typography variant="body1" align="center">
                            No books available
                        </Typography>
                    )}
                </Grid>
            </Container>
        </>
    );
};

export default BrowseProducts;
