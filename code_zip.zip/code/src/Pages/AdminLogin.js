import React, { useState } from 'react';
import { TextField, Button, Typography, Container, Box, Alert, InputAdornment } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { Email as EmailIcon, Lock as LockIcon } from '@mui/icons-material';

const AdminLogin = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleAdminLogin = async () => {
    const payload = {
      email: email,
      password: password,
    };

    try {
      const response = await fetch('http://localhost:8080/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        setError('Invalid credentials or error logging in');
      } else {
        // Redirect to admin dashboard after successful login
        navigate('/admin-dashboard');
      }
    } catch (err) {
      setError('Failed to log in. Try again later.');
    }
  };

  return (
    <Container maxWidth="xs" style={{ backgroundColor: '#f4f6f8', padding: '20px', borderRadius: '10px', boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.1)' }}>
      <Box textAlign="center" mb={3}>
        <Typography variant="h4" gutterBottom color="primary">
          Admin Login
        </Typography>
      </Box>
      {error && <Alert severity="error">{error}</Alert>}
      <TextField
        label="Email"
        variant="outlined"
        fullWidth
        margin="normal"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <EmailIcon color="primary" />
            </InputAdornment>
          ),
        }}
      />
      <TextField
        label="Password"
        variant="outlined"
        fullWidth
        type="password"
        margin="normal"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <LockIcon color="primary" />
            </InputAdornment>
          ),
        }}
      />
      <Button
        variant="contained"
        color="primary"
        fullWidth
        style={{ marginTop: '20px', padding: '10px' }}
        onClick={handleAdminLogin}
      >
        Login
      </Button>
    </Container>
  );
};

export default AdminLogin;
