package com.example.sample.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Student {
	
	@Id
	int RollNo;
	String Name;
	double Fee;
	
	Student(){
		
	}

	public Student(int rollNo, String name, double fee) {
		super();
		RollNo = rollNo;
		Name = name;
		Fee = fee;
	}

	public int getRollNo() {
		return RollNo;
	}

	public void setRollNo(int rollNo) {
		RollNo = rollNo;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public double getFee() {
		return Fee;
	}

	public void setFee(double fee) {
		Fee = fee;
	}

	@Override
	public String toString() {
		return "Student [RollNo=" + RollNo + ", Name=" + Name + ", Fee=" + Fee + "]";
	}
	
	
	
	
	

}
