package com.example.sample.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.sample.Dao.RepStudent;
import com.example.sample.Entity.Student;

@Service
public class StudentService {

	@Autowired
	RepStudent RepSt;

	public Student saveSt(Student s)

	{
		Student s2 = RepSt.save(s);
		return s2;
	}

	public List<Student> getStuds() {
		List<Student> l = (List) RepSt.findAll();

		return l;
	}
	
	
	public List<Student> getStudsByRN(int rno) {
	    
	    Optional<Student> studentOptional = RepSt.findById(rno);

	    
	    if (studentOptional.isPresent()) {
	        
	        List<Student> studentList = new ArrayList<>();
	        studentList.add(studentOptional.get());
	        return studentList;
	    } else {
	        
	        return null;
	    }
	}


	public Student removeSd(int rno) {

		Student s = RepSt.findById(rno).orElse(null);
		if (s == null) {
			return null;
		}

		else {

			RepSt.delete(s);
		}

		return s;

	}

	public String updateNM(String nm, int rn) {
		
		Student s=RepSt.findById(rn).orElse(null);
		
		if(s==null) {
			return "not found";
		}
		
		else {
			s.setName(nm);
			RepSt.save(s);
			
			return "Name Updated";
		}
		

	}
	
	
}