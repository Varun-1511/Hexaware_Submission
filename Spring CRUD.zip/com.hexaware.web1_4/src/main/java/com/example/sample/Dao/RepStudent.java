package com.example.sample.Dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.sample.Entity.Student;

@Repository
public interface RepStudent extends CrudRepository<Student, Integer>{
	

}
