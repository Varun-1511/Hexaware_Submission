package com.example.sample.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.sample.Entity.Student;
import com.example.sample.Service.StudentService;

@RestController
public class StudentController {

    @Autowired
    StudentService studSer;

    @PostMapping("/saveStudent")
    public Student saveStudent(@RequestBody Student s) {
        return studSer.saveSt(s);
    }

    @GetMapping("/getStudents")
    public List<Student> getStudents() {
        return studSer.getStuds();
    }

    @DeleteMapping("/removeStud/{rno}")
    public Student removeStud(@PathVariable int rno) {
        return studSer.removeSd(rno);
    }

    @PutMapping("/updateName/{rn}/{nm}")
    public String updateName(@PathVariable String nm, @PathVariable int rn) {
        return studSer.updateNM(nm, rn);
    }

    @GetMapping("/getStudentsByRN/{rno}")
    public List<Student> getStudentsByRN(@PathVariable int rno) {
        return studSer.getStudsByRN(rno);
    }
}
