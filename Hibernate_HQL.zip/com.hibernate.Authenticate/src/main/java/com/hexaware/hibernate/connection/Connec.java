package com.hexaware.hibernate.connection;

import com.hexaware.hibernate.entity.Login;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Connec {
    private static SessionFactory factory;

    static {
        try {
            factory = new Configuration().configure("hibernate.cfg.xml")
                    .addAnnotatedClass(Login.class)
                    .buildSessionFactory();
        } catch (Throwable ex) {
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static SessionFactory getSessionFactory() {
        return factory;
    }
}