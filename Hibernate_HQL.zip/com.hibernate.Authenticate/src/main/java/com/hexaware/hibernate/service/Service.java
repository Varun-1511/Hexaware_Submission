package com.hexaware.hibernate.service;

import com.hexaware.hibernate.dao.DAO;
import com.hexaware.hibernate.dao.DAOImpl;
import com.hexaware.hibernate.entity.Login;
import java.util.Scanner;

public class Service {
    private DAO dao = new DAOImpl();

    public void signIn() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter User ID:");
        int id = sc.nextInt();
        System.out.println("Enter Password:");
        String pass = sc.next();
        dao.signIn(id, pass);
    }

    public void signUp() {
        Scanner sc = new Scanner(System.in);
        Login login = new Login();
        System.out.println("Enter User ID:");
        login.setUserId(sc.nextInt());
        System.out.println("Enter Password:");
        login.setUserPass(sc.next());
        System.out.println("Enter Email:");
        login.setEmail(sc.next());
        dao.signUp(login);
    }

    public void removeAccount() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter User ID to remove:");
        int id = sc.nextInt();
        dao.removeAccount(id);
    }

    public void updatePassword() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter User ID:");
        int id = sc.nextInt();
        System.out.println("Enter New Password:");
        String newPassword = sc.next();
        dao.updatePassword(id, newPassword);
    }
}
