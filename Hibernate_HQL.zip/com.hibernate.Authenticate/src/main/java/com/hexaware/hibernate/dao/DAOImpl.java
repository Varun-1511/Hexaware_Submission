package com.hexaware.hibernate.dao;

import com.hexaware.hibernate.connection.Connec;
import com.hexaware.hibernate.entity.Login;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class DAOImpl implements DAO {

    @Override
    public void signIn(int id, String pass) {
        Session session = Connec.getSessionFactory().openSession();
        Login login = session.get(Login.class, id);
        if (login != null && login.getUserPass().equals(pass)) {
            System.out.println("Login Successful");
        } else {
            System.out.println("Invalid User ID or Password");
        }
        session.close();
    }

    @Override
    public void signUp(Login login) {
        Session session = Connec.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(login);
        tx.commit();
        session.close();
        System.out.println("Sign Up Successful");
    }

    @Override
    public void removeAccount(int id) {
        Session session = Connec.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        Login login = session.get(Login.class, id);
        if (login != null) {
            session.delete(login);
            tx.commit();
            System.out.println("Account Removed");
        } else {
            System.out.println("User Not Found");
        }
        session.close();
    }

    @Override
    public void updatePassword(int id, String newPassword) {
        Session session = Connec.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        Login login = session.get(Login.class, id);
        if (login != null) {
            login.setUserPass(newPassword);
            session.update(login);
            tx.commit();
            System.out.println("Password Updated");
        } else {
            System.out.println("User Not Found");
        }
        session.close();
    }
}