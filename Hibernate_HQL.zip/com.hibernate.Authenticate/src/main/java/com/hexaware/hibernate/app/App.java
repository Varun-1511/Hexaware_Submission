package com.hexaware.hibernate.app;

import com.hexaware.hibernate.service.Service;
import java.util.Scanner;

public class App {

    public static void main(String[] args) {
        Service service = new Service();
        Scanner sc = new Scanner(System.in);
        System.out.println("1. Sign In");
        System.out.println("2. Sign Up");
        System.out.println("3. Remove Account");
        System.out.println("4. Update Password");
        System.out.println("Enter your choice:");
        int choice = sc.nextInt();

        switch (choice) {
            case 1:
                service.signIn();
                break;
            case 2:
                service.signUp();
                break;
            case 3:
                service.removeAccount();
                break;
            case 4:
                service.updatePassword();
                break;
            default:
                System.out.println("Invalid Choice");
        }
    }
}
