package com.hexaware.hibernate.dao;

import com.hexaware.hibernate.entity.Login;

public interface DAO {
    void signIn(int id, String pass);
    void signUp(Login login);
    void removeAccount(int id);
    void updatePassword(int id, String newPassword);
}
