package com.hexaware.maven;

import org.springframework.context.annotation.Bean;

    public class StudentConfig {
        @Bean(name="stud1")
        public Student getStudent()

        {
            Student s1= new Student();
            s1.setRoll(101);
            s1.setName("Arti");
            s1.setFee(2000.9);
            return s1;
        }
        @Bean(name="stud2")
        public Student getStudent2()

        {
            Student s2 = new Student();
            s2.setRoll(102);
            s2.setName("Varun");
            s2.setFee(1000);
            return s2;
        }

        @Bean(name="res")
        public Result getResult()
        {
            Result r = new Result();
            r.setMarks(100);
            r.setRemarks("Pass");
            return r;
        }



    }

