package com.hexaware.maven;

import org.springframework.beans.factory.annotation.Autowired;

public class Student {

    int Roll;
    String Name;
    double Fee;

    @Autowired
    Result r;

    public Result getR() {
        return r;
    }

    public void setR(Result r) {
        this.r = r;
    }

    public int getRollNo() {
        return Roll;
    }

    public void setRoll(int roll) {
        Roll = roll;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public double getFee() {
        return Fee;
    }

    public void setFee(double fee) {
        Fee = fee;
    }

    @Override
    public String toString() {
        return "Student{" +
                "RollNo=" + Roll +
                ", Name='" + Name + '\'' +
                ", Fee=" + Fee +
                '}';
    }
}
