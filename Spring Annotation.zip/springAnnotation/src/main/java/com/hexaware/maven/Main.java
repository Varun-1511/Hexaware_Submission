package com.hexaware.maven;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext anno=new AnnotationConfigApplicationContext(StudentConfig.class);
        Student s=(Student)anno.getBean("stud1");
        System.out.println(s.toString());

        AnnotationConfigApplicationContext anno2=new AnnotationConfigApplicationContext(StudentConfig.class);
        Student s2=(Student)anno.getBean("stud2");
        System.out.println(s2.toString());

        Result res =s2.getR();
        System.out.println(res);


    }
}


