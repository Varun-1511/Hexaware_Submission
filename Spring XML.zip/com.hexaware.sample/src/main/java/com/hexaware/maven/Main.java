package com.hexaware.maven;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class Main
{
    public static void main( String[] args )
    {
        ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
        Student s1=(Student) context.getBean("stud1");
        Result res=s1.getRes();

        System.out.println( s1.toString() );

        System.out.println(res.toString());


//        ApplicationContext context1= new ClassPathXmlApplicationContext("beans.xml");
//        Books b1=(Books) context1.getBean("book1");
//        System.out.println(b1.toString());



    }
}

